
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  private products: Array<any> = [
    { 'pName': 'Angular', 'pid': 1 },
    { 'pName': 'MongoDB', 'pid': 2 },
    { 'pName': 'NodeJS', 'pid': 3 },
    { 'pName': 'ReactJS', 'pid': 4 }
  ]
  myFun(arg1) {
    alert(arg1)
  }
}
