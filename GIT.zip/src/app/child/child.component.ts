import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Input() pName;
  @Input() pid;
  @Output() send: EventEmitter<any> = new EventEmitter();
  clickMe(): any {
    this.send.emit(this.pid + this.pName)
  }
  constructor() { }
  ngOnInit() {
  }

}
